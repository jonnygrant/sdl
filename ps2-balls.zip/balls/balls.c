
/*
  Conservation of momentum balls
  J. Grant
  
  Physics equasions from previous experience and old programming book (LaMothe)
  
  PS2 code based on source by Tony Saveski, modified/improved
  by J. Grant for this program.
  
  Some cool "unexpected" results happen when discs collide, eg, two might be 
  locked together for a few seconds.  Spinning in tandem!

*/

//#include <stdlib.h>
//#include <stddef.h>
//#include <math.h>
//#include <tamtypes.h>


#include "floatlib.h"
#include "g2.h"
#include "gs.h"


/* Textures */

extern uint32 cd_w;
extern uint32 cd_h;
extern uint32 cd[];


//#define DEBUG

#define RAND_A 9301
#define RAND_C 49297
#define RAND_M 233280

#define DOT_PRODUCT(ux,uy,vx,vy) ((ux)*(vx) + (uy)*(vy))

#define BOXES 20

typedef struct
{
  float vx;
  float vy;
}
VECTOR2D;


typedef struct
{
  float radius;
  int mass;
  VECTOR2D velocity;
  VECTOR2D position;
  int r, g, b;
}
object;

object boxes[BOXES];

/* Perfect, elastic collisions, not real world, but great for demos :)
   Using float, so no increase/decrease for overall total velocity in the system
   like PSX suffers from due to no FPU
*/
static const float ecof = 1.0f;

/* Constants */
static uint32 seed = 0x12345678;
static const float VELOCITY = 5;
static const uint32 RADIUS = 5;
static const uint32 MASS = 4;
static int32 time = 0;



/* Functions */
int initalise_physics(void);
void physics_demo(void);
void check_edges(void);
int check_collisions(void);

void flip_buffers();

int main(void)
{

  if (gs_is_ntsc())
    g2_init(NTSC_512_224_32);
  else
    g2_init(PAL_512_256_32);

  initalise_physics();

  while (1)
   {
     /* Clear screen, of previus frame */
     g2_set_fill_color(0, 0, 0);
     g2_fill_rect(0, 0, g2_get_max_x(), g2_get_max_y());

     physics_demo();

     flip_buffers();

     time++;
   }

  g2_end();
  return (0);
}


float crap_rand(void)
{
  seed = (seed * RAND_A + RAND_C) % RAND_M;
  return ((float) seed / (float) RAND_M);
}


/* Using conservation of momentum equasions calc:
  va2 = (e+1)*mb*vb1+va1(ma - e*mb)/(ma+mb)
  vb2 = (e+1)*ma*va1+vb1(ma - e*mb)/(ma+mb)
*/

int check_collisions(void)
{
  int ball_a = 0;
  int ball_b = 0;
  float nabx, naby, length;
  float ma, mb;
  float tabx, taby;
  float vait, vain, vbit, vbin;
  float vafn, vbfn;
  float vaft, vbft;
  float xfa, yfa, xfb, yfb;

  for (ball_a = 0; ball_a < BOXES; ball_a++)
   {
     for (ball_b = ball_a + 1; ball_b < BOXES; ball_b++)
      {
	if (ball_a == ball_b)
	  continue;


	/* Calc the normal vector between the two compared boxes. length shows how close! */
	nabx = (boxes[ball_b].position.vx - boxes[ball_a].position.vx);
	naby = (boxes[ball_b].position.vy - boxes[ball_a].position.vy);
	length = sqrtf(nabx * nabx + naby * naby);

	/* Check for collision by using RADIUS of the disc */
	if (length <= 2.0f * RADIUS * 1.4f)
	 {

	   /* Normalise by the distance between the two boxes */
	   nabx /= length;
	   naby /= length;

	   /* tangential vector is perpendicular to normal, simply rotate vector 90 */
	   tabx = -naby;
	   taby = nabx;

	   vait = DOT_PRODUCT(boxes[ball_a].velocity.vx, boxes[ball_a].velocity.vy, tabx, taby);

	   vain = DOT_PRODUCT(boxes[ball_a].velocity.vx, boxes[ball_a].velocity.vy, nabx, naby);

	   vbit = DOT_PRODUCT(boxes[ball_b].velocity.vx, boxes[ball_b].velocity.vy, tabx, taby);

	   vbin = DOT_PRODUCT(boxes[ball_b].velocity.vx, boxes[ball_b].velocity.vy, nabx, naby);

	   ma = mb = MASS;

	   vafn = (mb * vbin * (ecof + 1) + vain * (ma - ecof * mb)) / (ma + mb);
	   vbfn = (ma * vain * (ecof + 1) - vbin * (ma - ecof * mb)) / (ma + mb);

	   /* tangential components is the same as before */
	   vaft = vait;
	   vbft = vbit;

	   /* Change n,t from co-ords back to x,y co-ords */

	   xfa = vafn * nabx + vaft * tabx;
	   yfa = vafn * naby + vaft * taby;

	   xfb = vbfn * nabx + vbft * tabx;
	   yfb = vbfn * naby + vbft * taby;

	   boxes[ball_a].velocity.vx = xfa;
	   boxes[ball_a].velocity.vy = yfa;

	   boxes[ball_b].velocity.vx = xfb;
	   boxes[ball_b].velocity.vy = yfb;

	   /* Update their positions to avoid another collision */
	   boxes[ball_a].position.vx += boxes[ball_a].velocity.vx;
	   boxes[ball_a].position.vy += boxes[ball_a].velocity.vy;

	   boxes[ball_b].position.vx += boxes[ball_b].velocity.vx;
	   boxes[ball_b].position.vy += boxes[ball_b].velocity.vy;
	 }
      }
   }
   return 0;
}



void physics_demo(void)
{
  uint32 loop;

  for (loop = 0; loop < BOXES; loop++)
   {
    g2_put_image(boxes[loop].position.vx - boxes[loop].radius, 
    		boxes[loop].position.vy - boxes[loop].radius, cd_w, cd_h, cd);

/* Block draw mode, no textures */
/*
     g2_set_fill_color((uint8) (crap_rand() * 255), (uint8) (crap_rand() * 255), (uint8) (crap_rand() * 255));
     g2_set_fill_color(boxes[loop].r, boxes[loop].g, boxes[loop].b);
     g2_fill_rect((uint16) boxes[loop].position.vx - boxes[loop].radius,
		  (uint16) boxes[loop].position.vy - boxes[loop].radius,
		  (uint16) boxes[loop].position.vx + boxes[loop].radius,
		  (uint16) boxes[loop].position.vy + boxes[loop].radius);
*/
   }


  /* Check if boxes are over the edge of the screen */
  check_edges();

  /* Check for collisions with other boxes, then calc the new velocity */
  check_collisions();


/* When debugging slow down the updates based on velocity */
#ifdef DEBUG
  if (time % 10 == 0)
   {
#endif
     // update positions
     for (loop = 0; loop < BOXES; loop++)
      {
	boxes[loop].position.vx += boxes[loop].velocity.vx;
	boxes[loop].position.vy += boxes[loop].velocity.vy;
      }
#ifdef DEBUG
   }
#endif

}


/* Check of boxes are off the screen on any of the 4 sides, and invert 
   their velocity in that direction. Include extra velocity update to avoid
   boxes being trapped at edge of the screen.
*/
void check_edges(void)
{
  uint32 loop;

  for (loop = 0; loop < BOXES; loop++)
   {
     if ((boxes[loop].position.vx + boxes[loop].velocity.vx + RADIUS) > g2_get_max_x() - 20)
     {
       boxes[loop].velocity.vx *= -1;
       boxes[loop].position.vx += boxes[loop].velocity.vx;
     }

     if ((boxes[loop].position.vy + boxes[loop].velocity.vy + RADIUS) > g2_get_max_y() - 20)
       {
        boxes[loop].velocity.vy *= -1;
	boxes[loop].position.vy += boxes[loop].velocity.vy;
       }


     // use + for velocity to evaluate its true sign, +- evaluates to -   but  -- evaluates to + !!
     if ((boxes[loop].position.vx + boxes[loop].velocity.vx - RADIUS) < 20)
     {
       boxes[loop].velocity.vx *= -1;
       boxes[loop].position.vx += boxes[loop].velocity.vx;
     }

     if ((boxes[loop].position.vy + boxes[loop].velocity.vy - RADIUS) < 20)
     {
       boxes[loop].velocity.vy *= -1;
       boxes[loop].position.vy += boxes[loop].velocity.vy;
     }
   }

}


/* PS2 function, wait for end of frame, then flip */
void flip_buffers(void)
{
  g2_wait_vsync();
  g2_set_visible_frame(1 - g2_get_visible_frame());
  g2_set_active_frame(1 - g2_get_active_frame());
}


int initalise_physics(void)
{
  int loop;

  for (loop = 0; loop < BOXES; loop++)
   {
     boxes[loop].radius = RADIUS;
     boxes[loop].mass = MASS;
     boxes[loop].velocity.vx = (crap_rand() * VELOCITY) - VELOCITY / 2;
     boxes[loop].velocity.vy = (crap_rand() * VELOCITY) - VELOCITY / 2;

     /* Ensure boxes start in main area of screen */
     boxes[loop].position.vx = crap_rand() * (g2_get_max_x() - 40) + 20;
     boxes[loop].position.vy = crap_rand() * (g2_get_max_y() - 40) + 20;
     boxes[loop].r = crap_rand() * 255;
     boxes[loop].g = crap_rand() * 255;
     boxes[loop].b = crap_rand() * 255;
   }
  return 0;
}



